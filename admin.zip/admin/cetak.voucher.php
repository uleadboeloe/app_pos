<?php
echo "<H1>CETAK VOUCHER</H1>";
?>