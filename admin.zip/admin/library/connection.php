<?php
$HostName	= "localhost:3309";
$HostUser	= "root";
$HostPass	= "";
$HostDb	= "insanpos_db";

/*
$HostName	= "103.82.241.166";
$HostUser	= "insandev";
$HostPass	= "1n54nD3v";
$HostDb	= "insanpos_db";

$HostName	= "localhost";
$HostUser	= "eddyw";
$HostPass	= "$998165Aja";
$HostDb	= "insanpos_db";
*/
$koneksidb	= ($GLOBALS["___mysqli_ston_"] = mysqli_connect($HostName,  $HostUser,  $HostPass));
if (! $koneksidb) {
  echo "Koneksi Gagal Terhubung<br>";
  exit;
}

mysqli_select_db($GLOBALS["___mysqli_ston_"], $HostDb) or die ("Database Tidak Ditemukan, Silahkan Hubungi Customer Service Kami!");
?>