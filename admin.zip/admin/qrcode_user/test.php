<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator Sederhana</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f0f2f5; /* Warna latar belakang yang lembut */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }
        .calculator {
            background-color: #ffffff;
            border-radius: 20px; /* Sudut lebih membulat */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1); /* Bayangan yang lebih menonjol */
            width: 100%;
            max-width: 360px; /* Lebar maksimum untuk tampilan seperti ponsel */
            overflow: hidden;
            display: flex;
            flex-direction: column;
            padding: 20px;
        }
        .display {
            background-color: #282c34; /* Warna gelap untuk tampilan */
            color: #ffffff;
            font-size: 2.8em; /* Ukuran font lebih besar */
            text-align: right;
            padding: 20px;
            border-radius: 15px; /* Sudut membulat untuk tampilan */
            margin-bottom: 20px;
            min-height: 80px; /* Tinggi minimum untuk tampilan */
            display: flex;
            align-items: flex-end;
            justify-content: flex-end;
            word-wrap: break-word; /* Memastikan teks tidak meluap */
            overflow-x: auto; /* Scroll horizontal jika terlalu panjang */
        }
        .buttons-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px; /* Jarak antar tombol */
        }
        .button {
            background-color: #e0e0e0; /* Warna tombol default */
            color: #333333;
            font-size: 1.5em; /* Ukuran font tombol */
            padding: 20px 0;
            border-radius: 15px; /* Sudut membulat untuk tombol */
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: background-color 0.2s ease, transform 0.1s ease;
            user-select: none; /* Mencegah seleksi teks */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08); /* Bayangan tombol */
        }
        .button:hover {
            background-color: #d0d0d0;
            transform: translateY(-2px); /* Efek angkat saat hover */
        }
        .button:active {
            background-color: #c0c0c0;
            transform: translateY(0); /* Efek tekan saat aktif */
        }
        .button.operator {
            background-color: #f9a825; /* Warna oranye untuk operator */
            color: #ffffff;
        }
        .button.operator:hover {
            background-color: #e69500;
        }
        .button.operator:active {
            background-color: #d38200;
        }
        .button.clear {
            background-color: #ef5350; /* Warna merah untuk tombol clear */
            color: #ffffff;
        }
        .button.clear:hover {
            background-color: #d84315;
        }
        .button.clear:active {
            background-color: #c23b10;
        }
        .button.equals {
            background-color: #4caf50; /* Warna hijau untuk tombol sama dengan */
            color: #ffffff;
            grid-column: span 2; /* Tombol sama dengan mengambil 2 kolom */
        }
        .button.equals:hover {
            background-color: #43a047;
        }
        .button.equals:active {
            background-color: #388e3c;
        }

        /* Responsiveness */
        @media (max-width: 400px) {
            .calculator {
                padding: 15px;
            }
            .display {
                font-size: 2.5em;
                padding: 15px;
            }
            .button {
                font-size: 1.3em;
                padding: 15px 0;
            }
            .buttons-grid {
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="calculator">
        <div class="display" id="display">0</div>
        <div class="buttons-grid">
            <div class="button clear" onclick="clearDisplay()">C</div>
            <div class="button operator" onclick="appendOperator('/')">/</div>
            <div class="button operator" onclick="appendOperator('*')">*</div>
            <div class="button" onclick="appendNumber('7')">7</div>
            <div class="button" onclick="appendNumber('8')">8</div>
            <div class="button" onclick="appendNumber('9')">9</div>
            <div class="button operator" onclick="appendOperator('-')">-</div>
            <div class="button" onclick="appendNumber('4')">4</div>
            <div class="button" onclick="appendNumber('5')">5</div>
            <div class="button" onclick="appendNumber('6')">6</div>
            <div class="button operator" onclick="appendOperator('+')">+</div>
            <div class="button" onclick="appendNumber('1')">1</div>
            <div class="button" onclick="appendNumber('2')">2</div>
            <div class="button" onclick="appendNumber('3')">3</div>
            <div class="button" onclick="appendNumber('0')">0</div>
            <div class="button" onclick="appendNumber('.')">.</div>
            <div class="button equals" onclick="calculateResult()">=</div>
        </div>
    </div>

    <script>
        const display = document.getElementById('display');
        let currentInput = '0';
        let operator = null;
        let previousInput = '';
        let waitingForNewInput = false;

        // Fungsi untuk memperbarui tampilan
        function updateDisplay() {
            display.textContent = currentInput;
        }

        // Menambahkan angka ke input saat ini
        function appendNumber(number) {
            if (waitingForNewInput) {
                currentInput = number;
                waitingForNewInput = false;
            } else {
                if (currentInput === '0' && number !== '.') {
                    currentInput = number;
                } else if (number === '.' && currentInput.includes('.')) {
                    // Jangan tambahkan titik desimal ganda
                    return;
                } else {
                    currentInput += number;
                }
            }
            updateDisplay();
        }

        // Menambahkan operator
        function appendOperator(op) {
            if (operator && !waitingForNewInput) {
                // Jika ada operator sebelumnya dan bukan input baru, hitung dulu
                calculateResult();
            }
            previousInput = currentInput;
            operator = op;
            waitingForNewInput = true;
            updateDisplay(); // Tampilkan angka sebelumnya
        }

        // Menghitung hasil
        function calculateResult() {
            if (!operator || previousInput === '') {
                return; // Tidak ada operasi yang perlu dihitung
            }

            let result;
            const prev = parseFloat(previousInput);
            const current = parseFloat(currentInput);

            if (isNaN(prev) || isNaN(current)) {
                currentInput = 'Error';
                updateDisplay();
                resetCalculator();
                return;
            }

            switch (operator) {
                case '+':
                    result = prev + current;
                    break;
                case '-':
                    result = prev - current;
                    break;
                case '*':
                    result = prev * current;
                    break;
                case '/':
                    if (current === 0) {
                        currentInput = 'Error: Bagi 0';
                        updateDisplay();
                        resetCalculator();
                        return;
                    }
                    result = prev / current;
                    break;
                default:
                    return;
            }

            // Batasi jumlah digit desimal untuk hasil
            currentInput = parseFloat(result.toFixed(8)).toString();
            operator = null;
            previousInput = '';
            waitingForNewInput = true; // Setelah hitung, siap untuk input baru
            updateDisplay();
        }

        // Mengatur ulang kalkulator
        function clearDisplay() {
            currentInput = '0';
            operator = null;
            previousInput = '';
            waitingForNewInput = false;
            updateDisplay();
        }

        // Fungsi untuk mereset setelah error
        function resetCalculator() {
            operator = null;
            previousInput = '';
            waitingForNewInput = false;
        }

        // Inisialisasi tampilan saat halaman dimuat
        window.onload = function() {
            updateDisplay();
        };
    </script>
</body>
</html>