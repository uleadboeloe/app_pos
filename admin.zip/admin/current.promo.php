
<?php
include_once "library/connection.php";
include_once "library/parameter.php";
include_once "library/fungsi.php";
include_once "../lib_dbo/user_functions.php";

header('Content-Type: application/json');
$kodestore = $_GET['kode_store'];

$StrViewQuery="SELECT * from dbo_promo where fl_active = 1 and kode_store = '" . $kodestore . "' order by promo_start_date desc";
$callStrViewQuery=mysqli_query($koneksidb, $StrViewQuery);
mysqli_data_seek($callStrViewQuery, 0); // reset pointer
$promoList = [];
while($recView = mysqli_fetch_assoc($callStrViewQuery)) {
    $promoList[] = $recView;
}
echo json_encode($promoList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
?>
                    