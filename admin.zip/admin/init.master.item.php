<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include_once "library/connection.php";
include_once "library/parameter.php";
include_once "library/fungsi.php";

echo "MASUK INI MASTER ITEM <br>";

//$ftp_server = "ftp.amanahmart.id";
//$ftp_username = "IT";
//$ftp_password = "It@123";
//$ftp_port = "21";

//$ftp_file = "/MASTERBC/A101/Item20250420.txt";
$local_file = "../dbo_schema/ExportItem4NewPOS.txt";

/*===============Tarik Flatfile Daily BC===================================
// Initialize cURL
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "ftp://$ftp_server$ftp_file");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, "$ftp_username:$ftp_password");
curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
curl_setopt($ch, CURLOPT_PORT, $ftp_port);
// Open file to write
$fp = fopen($local_file, 'w');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch) . "<br>";
    //insert log error here, datetime, error message
} else {
    echo 'File downloaded successfully<br>';
    //insert log error here, datetime, error message
}
fclose($fp);
curl_close($ch);
===============Tarik Flatfile Master Kategori Daily BC===================================
*/
$Filesize = filesize($local_file);
if($Filesize > 0){
    $myfiles = fopen($local_file, "r") or die("Unable to open file!");
    $KontenFiles = fread($myfiles,filesize($local_file));
    //echo "Data Item : " .$KontenFiles."<br>";

    $varArrays = explode("^",$KontenFiles);
    $CountArrays = count($varArrays);
    //echo "Count Array : " .$varArrays."<br>";

    $varDataItem = explode("^", $KontenFiles);
    for($j=0;$j<$CountArrays;$j++){
        $varStrings = $varDataItem[$j];
        $varDataItemLine = explode("|", $varStrings);
        //echo "String to explode: " .$varStrings . "<br>";
        
        $varKdStore = $varDataItemLine[0];
        $varSkuBarang = $varDataItemLine[1];
        $varKodeBarang = $varDataItemLine[1];
        $varBarcodeBarang = $varDataItemLine[2] ?? "0";
        $varNamaBarang = cleanWeirdCharacters($varDataItemLine[3]);
        $varNamaBarang = str_replace("'", "`", $varNamaBarang);

        $RandomCode = md5($varNamaBarang);
        $CreateUrl = create_url($varNamaBarang);            

        $varPrincipal = $varDataItemLine[4];
        $varDivisi = $varDataItemLine[7];
        $varDept = $varDataItemLine[6];
        $varSubDept = $varDataItemLine[5];
        $varPPN = $varDataItemLine[9];
        if($varPPN == "VAT"){
            $varPPNx = "11";
        }else{
            $varPPNx = "0";
        }

        $varTimbang = $varDataItemLine[10];
        if($varTimbang == "No"){
            $varTimbangx = "False";
            $FlTimbang = 0;
        }else{
            $varTimbangx = "True";
            $FlTimbang = 1;
        }
        $varKemasanSedang = replacenumbers($varDataItemLine[11] ?? "0");
        $varKemasanBesar = replacenumbers($varDataItemLine[12] ?? "0");
        $varMinStok = replacenumbers($varDataItemLine[13] ?? "0");
        $varMaxStok = replacenumbers($varDataItemLine[14] ?? "0");
        $varVendor = $varDataItemLine[15];
        $varUom3 = $varDataItemLine[8];
        $varUom1 = $varDataItemLine[16];
        $varUom2 = $varDataItemLine[17];
    
        $varHargaJual1 = replacenumbers($varDataItemLine[18]);
        $varHargaBeli1 = replacenumbers($varDataItemLine[19]);
        $varHargaJual2 = replacenumbers($varDataItemLine[20]);
        $varHargaBeli2 = replacenumbers($varDataItemLine[21]);
        $varHargaJual3 = replacenumbers($varDataItemLine[22]);
        $varHargaBeli3 = replacenumbers($varDataItemLine[23]);
        //echo "Kode Store : " . $varKdStore . "#";
        $varBarcode2 = $varDataItemLine[24] ?? "0";
        $varBarcode3 = $varDataItemLine[25] ?? "0";

        if($varTimbangx == "True"){
            if($varBarcodeBarang == ""){
                $varBarcodeBarang = $varSkuBarang;
            }
            if($varBarcode2 == ""){
                $varBarcode2 = "0";
            }
            if($varBarcode3 == ""){
                $varBarcode3 = "0";
            }                

            $StrMstItem="SELECT * FROM dbo_barang where sku_barang = '" . $varSkuBarang . "'";
            $CallStrMstItem=mysqli_query($koneksidb, $StrMstItem);
            $Jumbar=mysqli_num_rows($CallStrMstItem);
            if ($Jumbar === 0 ){
                $strSQLMaster="INSERT INTO dbo_barang(
                `random_code`,`sku_barang`,`kode_barang`,`barcode`,`barcode2`,`barcode3`,
                `nama_barang`,`keterangan_1`,
                `sub_dept`,`dept`,`divisi`,`vendor_no`,`isi_kemasan_kecil`,
                `isi_kemasan_sedang`,`fl_timbang`,`url_named`,`uom`,`uom2`,`uom3`,
                `ppn`,`posting_date`,`posting_user`) VALUES(
                '$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcodeBarang','$varBarcode2','$varBarcode3',
                '$varNamaBarang','$varNamaBarang',
                '$varSubDept','$varDept','$varDivisi','$varVendor','$varKemasanSedang',
                '$varKemasanBesar','$FlTimbang','$CreateUrl','$varUom1','$varUom2','$varUom3',
                '$varPPNx','$datedb','ADMIN')";
                $executeSQLxz=mysqli_query($koneksidb, $strSQLMaster);
                echo "MASUK MASTER TIMBANG : <br>" . $strSQLMaster . "<br>";

                if(($varHargaJual1 > 0)&&($varUom1 != "")){
                    if($varBarcodeBarang == ""){
                        $varBarcodeBarang = "0";
                    }
                    $strSQLUpdateHJ1="INSERT INTO dbo_price(`random_code`,`sku_barang`,`kode_barang`,`barcode`,`uom`,`harga_jual`,`posting_date`,`posting_user`,`isi_kemasan`) VALUES 
                    ('$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcodeBarang','$varUom1','$varHargaJual1','$datedb','ADMIN','1')";
                    $executeSQLxx=mysqli_query($koneksidb, $strSQLUpdateHJ1);
                    //echo "MASUKIN HARGA JUAL 0 : <br>" . $strSQLUpdateHJ1 . "<br>";
                }
                //echo "<hr>";
            }

            $SkuTimbang = "2" . $varSkuBarang; 
            $varHargaTimbang = str_replace(".00", "", $varHargaJual1);                  
            $csvFile = fopen("../dbo_schema/digipos.csv", "w");
            if ($csvFile && $varTimbangx == "True") {
                $row = [
                    $SkuTimbang,
                    $varNamaBarang,
                    $varHargaTimbang
                ];
                fputcsv($csvFile, $row);
                fclose($csvFile);
            }
        }else{
            if($varBarcodeBarang == ""){
                $varBarcodeBarang = $varSkuBarang;
            }
            if($varBarcode2 == ""){
                $varBarcode2 = "0";
            }
            if($varBarcode3 == ""){
                $varBarcode3 = "0";
            }

            //if($varBarcodeBarang != "0"){
                $StrMstItem="SELECT * FROM dbo_barang where sku_barang = '" . $varSkuBarang . "'";
                $CallStrMstItem=mysqli_query($koneksidb, $StrMstItem);
                $Jumbar=mysqli_num_rows($CallStrMstItem);
                if ($Jumbar === 0 ){
                    $strSQLMaster="INSERT INTO dbo_barang(
                    `random_code`,`sku_barang`,`kode_barang`,`barcode`,`barcode2`,`barcode3`,
                    `nama_barang`,`keterangan_1`,
                    `sub_dept`,`dept`,`divisi`,`vendor_no`,`isi_kemasan_kecil`,
                    `isi_kemasan_sedang`,`fl_timbang`,`url_named`,`uom`,`uom2`,`uom3`,
                    `ppn`,`posting_date`,`posting_user`) VALUES(
                    '$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcodeBarang','$varBarcode2','$varBarcode3',
                    '$varNamaBarang','$varNamaBarang',
                    '$varSubDept','$varDept','$varDivisi','$varVendor','$varKemasanSedang',
                    '$varKemasanBesar','$FlTimbang','$CreateUrl','$varUom3','$varUom2','$varUom1',
                    '$varPPNx','$datedb','ADMIN')";
                    $executeSQLxz=mysqli_query($koneksidb, $strSQLMaster);
                    echo "MASUK MASTER NONTIMBANg : <br>" . $strSQLMaster . "<br>";

                    if(($varHargaJual3 > 0)&&($varUom3 != "")){
                        if($varBarcodeBarang == ""){
                            $varBarcodeBarang = "0";
                        }
                        $strSQLUpdateHJ1="INSERT INTO dbo_price(`random_code`,`sku_barang`,`kode_barang`,`barcode`,`uom`,`harga_jual`,`posting_date`,`posting_user`,`isi_kemasan`) VALUES 
                        ('$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcodeBarang','$varUom3','$varHargaJual3','$datedb','ADMIN','1')";
                        $executeSQLxx=mysqli_query($koneksidb, $strSQLUpdateHJ1);
                        //echo "MASUKIN HARGA JUAL 0 : <br>" . $strSQLUpdateHJ1 . "<br>";
                    }

                    if(($varHargaJual2 > 0)&&($varUom2 != "")){
                        if($varBarcode2 == "0"){
                            $varBarcode2 = "1" . $varBarcodeBarang;
                        }
                        $strSQLUpdateHJ1="INSERT INTO dbo_price(`random_code`,`sku_barang`,`kode_barang`,`barcode`,`uom`,`harga_jual`,`posting_date`,`posting_user`,`isi_kemasan`) VALUES 
                        ('$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcode2','$varUom2','$varHargaJual2','$datedb','ADMIN','$varKemasanSedang')";
                        $executeSQLxx=mysqli_query($koneksidb, $strSQLUpdateHJ1);
                        //echo "MASUKIN HARGA JUAL 0 : <br>" . $strSQLUpdateHJ1 . "<br>";
                    }
                    
                    if(($varHargaJual1 > 0)&&($varUom1 != "")){
                        if($varBarcode3 == "0"){
                            $varBarcode3 = "2" . $varBarcodeBarang;
                        }                        
                        $strSQLUpdateHJ1="INSERT INTO dbo_price(`random_code`,`sku_barang`,`kode_barang`,`barcode`,`uom`,`harga_jual`,`posting_date`,`posting_user`,`isi_kemasan`) VALUES 
                        ('$RandomCode','$varSkuBarang','$varSkuBarang','$varBarcode3','$varUom1','$varHargaJual1','$datedb','ADMIN','$varKemasanBesar')";
                        $executeSQLxx=mysqli_query($koneksidb, $strSQLUpdateHJ1);
                        //echo "MASUKIN HARGA JUAL 0 : <br>" . $strSQLUpdateHJ1 . "<br>";
                    }
                } 
            //}
            
        }
    }
    fclose($myfiles);
}
?>
