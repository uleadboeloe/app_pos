<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman dengan Tombol Fullscreen</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Menggunakan font Inter dari Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Gaya untuk elemen yang akan menjadi fullscreen */
        #fullscreen-container:-webkit-full-screen {
            width: 100%;
            height: 100%;
            background-color: #f0f9ff; /* Warna latar belakang saat fullscreen */
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        #fullscreen-container:-moz-full-screen {
            width: 100%;
            height: 100%;
            background-color: #f0f9ff;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        #fullscreen-container:-ms-full-screen {
            width: 100%;
            height: 100%;
            background-color: #f0f9ff;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        #fullscreen-container:full-screen {
            width: 100%;
            height: 100%;
            background-color: #f0f9ff;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        /* Untuk kompatibilitas lintas browser */
        #fullscreen-container:-webkit-full-screen #exit-fullscreen-message,
        #fullscreen-container:-moz-full-screen #exit-fullscreen-message,
        #fullscreen-container:-ms-full-screen #exit-fullscreen-message,
        #fullscreen-container:full-screen #exit-fullscreen-message {
            display: block; /* Tampilkan pesan saat fullscreen */
        }
        #exit-fullscreen-message {
            display: none; /* Sembunyikan secara default */
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen flex items-center justify-center p-4">

    <div id="fullscreen-container" class="bg-white p-8 rounded-xl shadow-lg max-w-2xl w-full text-center border border-gray-200">
        <h1 class="text-3xl font-bold text-gray-800 mb-4">Selamat Datang!</h1>
        <p class="text-lg text-gray-600 mb-6">
            Untuk pengalaman tampilan yang lebih imersif, silakan klik tombol di bawah ini untuk masuk ke mode layar penuh.
        </p>

        <button id="fullscreenButton"
                class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition duration-300 ease-in-out transform hover:scale-105 shadow-md">
            Aktifkan Mode Layar Penuh
        </button>

        <p id="exit-fullscreen-message" class="text-sm text-gray-500 mt-4">
            Tekan <span class="font-bold">Esc</span> untuk keluar dari mode layar penuh.
        </p>
    </div>

    <script>
        // Dapatkan referensi ke tombol dan elemen yang akan menjadi fullscreen
        const fullscreenButton = document.getElementById('fullscreenButton');
        const fullscreenContainer = document.getElementById('fullscreen-container');
        const exitFullscreenMessage = document.getElementById('exit-fullscreen-message');

        // Tambahkan event listener untuk klik tombol
        fullscreenButton.addEventListener('click', () => {
            try {
                // Periksa apakah browser mendukung Fullscreen API
                if (fullscreenContainer.requestFullscreen) {
                    fullscreenContainer.requestFullscreen();
                } else if (fullscreenContainer.webkitRequestFullscreen) { /* Safari */
                    fullscreenContainer.webkitRequestFullscreen();
                } else if (fullscreenContainer.msRequestFullscreen) { /* IE11 */
                    fullscreenContainer.msRequestFullscreen();
                }
            } catch (error) {
                // Tangani kesalahan jika permintaan fullscreen ditolak oleh kebijakan izin
                console.error('Gagal masuk mode fullscreen:', error);
                console.error('Kesalahan ini mungkin disebabkan oleh "Permissions Policy" pada iframe yang menyematkan halaman ini.');
                console.error('Pastikan iframe memiliki atribut `allow="fullscreen"` atau `allowfullscreen="true"`.');
                // Anda bisa menambahkan pesan kepada pengguna di UI di sini
                // Misalnya: alert('Browser Anda memblokir mode fullscreen otomatis. Silakan coba lagi atau periksa pengaturan browser Anda.');
            }
        });

        // Tambahkan event listener untuk memantau perubahan status fullscreen
        document.addEventListener('fullscreenchange', () => {
            if (document.fullscreenElement) {
                // Saat masuk mode fullscreen
                console.log('Masuk mode fullscreen');
                fullscreenButton.classList.add('hidden'); // Sembunyikan tombol saat fullscreen
                exitFullscreenMessage.classList.remove('hidden'); // Tampilkan pesan keluar
            } else {
                // Saat keluar mode fullscreen
                console.log('Keluar mode fullscreen');
                fullscreenButton.classList.remove('hidden'); // Tampilkan kembali tombol
                exitFullscreenMessage.classList.add('hidden'); // Sembunyikan pesan keluar
            }
        });

        // Tambahkan event listener untuk webkit (Safari)
        document.addEventListener('webkitfullscreenchange', () => {
            if (document.webkitFullscreenElement) {
                console.log('Masuk mode fullscreen (WebKit)');
                fullscreenButton.classList.add('hidden');
                exitFullscreenMessage.classList.remove('hidden');
            } else {
                console.log('Keluar mode fullscreen (WebKit)');
                fullscreenButton.classList.remove('hidden');
                exitFullscreenMessage.classList.add('hidden');
            }
        });

        // Tambahkan event listener untuk moz (Firefox)
        document.addEventListener('mozfullscreenchange', () => {
            if (document.mozFullScreenElement) {
                console.log('Masuk mode fullscreen (Mozilla)');
                fullscreenButton.classList.add('hidden');
                exitFullscreenMessage.classList.remove('hidden');
            } else {
                console.log('Keluar mode fullscreen (Mozilla)');
                fullscreenButton.classList.remove('hidden');
                exitFullscreenMessage.classList.add('hidden');
            }
        });

        // Tambahkan event listener untuk ms (IE/Edge)
        document.addEventListener('MSFullscreenChange', () => {
            if (document.msFullscreenElement) {
                console.log('Masuk mode fullscreen (MS)');
                fullscreenButton.classList.add('hidden');
                exitFullscreenMessage.classList.remove('hidden');
            } else {
                console.log('Keluar mode fullscreen (MS)');
                fullscreenButton.classList.remove('hidden');
                exitFullscreenMessage.classList.add('hidden');
            }
        });
    </script>
</body>
</html>
