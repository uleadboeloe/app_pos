<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permainan Balapan Mobil</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Menggunakan font Inter secara default */
        body {
            font-family: 'Inter', sans-serif;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }
        /* Styling khusus untuk canvas agar responsif */
        canvas {
            display: block; /* Menghilangkan spasi ekstra di bawah canvas */
            background-color: #f0f0f0; /* Warna latar belakang lintasan */
            border-radius: 0.75rem; /* Sudut membulat */
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); /* Bayangan */
        }
        /* Styling untuk tombol */
        .game-button {
            @apply px-6 py-3 rounded-xl font-semibold text-white shadow-lg transition-all duration-200 ease-in-out transform hover:scale-105 active:scale-95 focus:outline-none focus:ring-4 focus:ring-opacity-75;
        }
        .start-button {
            @apply bg-blue-600 hover:bg-blue-700 focus:ring-blue-300;
        }
        .car-button-red {
            @apply bg-red-600 hover:bg-red-700 focus:ring-red-300;
        }
        .car-button-green {
            @apply bg-green-600 hover:bg-green-700 focus:ring-green-300;
        }
        .car-button-blue {
            @apply bg-blue-600 hover:bg-blue-700 focus:ring-blue-300;
        }
        /* Styling untuk pesan */
        .message-box {
            @apply fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50;
        }
        .message-content {
            @apply bg-white p-8 rounded-xl shadow-2xl text-center max-w-sm w-full;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-purple-100 to-blue-200 min-h-screen flex items-center justify-center p-4">

    <div class="bg-white p-8 rounded-2xl shadow-xl max-w-4xl w-full flex flex-col items-center space-y-6">
        <h1 class="text-4xl font-extrabold text-gray-800 mb-4 text-center">Permainan Balapan Mobil</h1>

        <canvas id="raceCanvas" class="w-full h-auto max-h-[400px]"></canvas>

        <div class="text-center">
            <p id="statusMessage" class="text-lg font-medium text-gray-700">Tekan 'Mulai Balapan Baru' untuk memulai.</p>
            <p id="winnerMessage" class="text-2xl font-bold text-purple-700 mt-2"></p>
        </div>

        <div class="flex flex-wrap justify-center gap-4 mt-6">
            <button id="startButton" class="game-button start-button">Mulai Balapan Baru</button>
            <button id="car1Button" class="game-button car-button-red">Gerakkan Mobil Merah</button>
            <button id="car2Button" class="game-button car-button-green">Gerakkan Mobil Hijau</button>
            <button id="car3Button" class="game-button car-button-blue">Gerakkan Mobil Biru</button>
        </div>
    </div>

    <div id="customMessageBox" class="message-box hidden">
        <div class="message-content">
            <p id="messageText" class="text-xl font-semibold text-gray-800 mb-6"></p>
            <button id="messageCloseButton" class="game-button start-button">OK</button>
        </div>
    </div>

    <script>
        const canvas = document.getElementById('raceCanvas');
        const ctx = canvas.getContext('2d');

        const startButton = document.getElementById('startButton');
        const car1Button = document.getElementById('car1Button');
        const car2Button = document.getElementById('car2Button');
        const car3Button = document.getElementById('car3Button');

        const statusMessage = document.getElementById('statusMessage');
        const winnerMessage = document.getElementById('winnerMessage');

        const customMessageBox = document.getElementById('customMessageBox');
        const messageText = document.getElementById('messageText');
        const messageCloseButton = document.getElementById('messageCloseButton');

        // --- Game Settings ---
        const CAR_WIDTH = 70; // Increased width for images
        const CAR_HEIGHT = 40; // Increased height for images
        const TRACK_PADDING = 20; // Padding from canvas edges
        const FINISH_LINE_OFFSET = 80; // Distance of finish line from right edge
        const MIN_MOVE_DISTANCE = 5;
        const MAX_MOVE_DISTANCE = 15;

        let gameRunning = false;
        let cars = [];
        let finishLineX;

        // Function to show custom message box
        function showMessageBox(message) {
            messageText.textContent = message;
            customMessageBox.classList.remove('hidden');
        }

        // Function to hide custom message box
        function hideMessageBox() {
            customMessageBox.classList.add('hidden');
        }

        // Event listener for message box close button
        messageCloseButton.addEventListener('click', hideMessageBox);

        // Car Object
        class Car {
            constructor(name, color, yPos, imageUrl) {
                this.name = name;
                this.color = color;
                this.x = TRACK_PADDING; // Initial X position
                this.y = yPos;
                this.image = new Image();
                this.image.src = imageUrl;
                this.imageLoaded = false;

                // Ensure image is loaded before drawing
                this.image.onload = () => {
                    this.imageLoaded = true;
                    drawRaceTrack(); // Redraw once image is loaded
                };
                // Fallback for image loading errors
                this.image.onerror = () => {
                    console.error(`Failed to load image for ${this.name}: ${imageUrl}`);
                    // Draw a fallback rectangle if image fails to load
                    this.imageLoaded = false;
                    drawRaceTrack();
                };
            }

            draw() {
                if (this.imageLoaded) {
                    ctx.drawImage(this.image, this.x, this.y, CAR_WIDTH, CAR_HEIGHT);
                } else {
                    // Fallback to drawing a colored rectangle if image not loaded
                    ctx.fillStyle = this.color;
                    ctx.fillRect(this.x, this.y, CAR_WIDTH, CAR_HEIGHT);
                    ctx.strokeStyle = 'black';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(this.x, this.y, CAR_WIDTH, CAR_HEIGHT);
                }

                // Draw car name above it
                ctx.fillStyle = 'black';
                ctx.font = '12px Inter';
                ctx.textAlign = 'center';
                ctx.fillText(this.name, this.x + CAR_WIDTH / 2, this.y - 5);
            }

            move() {
                if (gameRunning) {
                    this.x += Math.floor(Math.random() * (MAX_MOVE_DISTANCE - MIN_MOVE_DISTANCE + 1)) + MIN_MOVE_DISTANCE;
                    drawRaceTrack(); // Clear canvas and redraw all elements
                    checkWinner();
                } else {
                    showMessageBox("Balapan belum dimulai atau sudah selesai! Tekan 'Mulai Balapan Baru'.");
                }
            }

            reset() {
                this.x = TRACK_PADDING;
            }
        }

        // Initialize Cars
        function initializeCars() {
            const trackHeight = canvas.height - (2 * TRACK_PADDING);
            const carSpacing = (trackHeight - (3 * CAR_HEIGHT)) / 2; // Spacing between cars

            cars = [
                new Car("Mobil Merah", "red", TRACK_PADDING, `https://placehold.co/${CAR_WIDTH}x${CAR_HEIGHT}/FF0000/FFFFFF?text=CAR1`),
                new Car("Mobil Hijau", "green", TRACK_PADDING + CAR_HEIGHT + carSpacing, `https://placehold.co/${CAR_WIDTH}x${CAR_HEIGHT}/00FF00/FFFFFF?text=CAR2`),
                new Car("Mobil Biru", "blue", TRACK_PADDING + (2 * CAR_HEIGHT) + (2 * carSpacing), `https://placehold.co/${CAR_WIDTH}x${CAR_HEIGHT}/0000FF/FFFFFF?text=CAR3`)
            ];
        }

        // Draw all elements on canvas
        function drawRaceTrack() {
            ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear canvas

            // Finish Line
            finishLineX = canvas.width - FINISH_LINE_OFFSET;
            ctx.strokeStyle = 'red';
            ctx.lineWidth = 4;
            ctx.setLineDash([10, 10]); // Dashed line
            ctx.beginPath();
            ctx.moveTo(finishLineX, 0);
            ctx.lineTo(finishLineX, canvas.height);
            ctx.stroke();
            ctx.setLineDash([]); // Reset dashed line

            // 'FINISH' Text
            ctx.fillStyle = 'red';
            ctx.font = '20px Inter';
            ctx.textAlign = 'center';
            ctx.fillText('FINISH', finishLineX + 40, canvas.height / 2);

            // Draw all cars
            cars.forEach(car => car.draw());
        }

        // Check for winner
        function checkWinner() {
            if (!gameRunning) return;

            for (const car of cars) {
                if (car.x + CAR_WIDTH >= finishLineX) {
                    gameRunning = false;
                    winnerMessage.textContent = `${car.name} MENANG!`;
                    statusMessage.textContent = "Balapan selesai!";
                    showMessageBox(`Selamat, ${car.name} adalah pemenangnya!`);
                    // Disable car buttons after race ends
                    car1Button.disabled = true;
                    car2Button.disabled = true;
                    car3Button.disabled = true;
                    return;
                }
            }
        }

        // Function to start/reset race
        function startGame() {
            gameRunning = true;
            statusMessage.textContent = "Balapan sedang berlangsung...";
            winnerMessage.textContent = "";
            cars.forEach(car => car.reset());
            drawRaceTrack(); // Redraw track and cars at start position

            // Re-enable car buttons
            car1Button.disabled = false;
            car2Button.disabled = false;
            car3Button.disabled = false;
        }

        // --- Event Listeners ---
        startButton.addEventListener('click', startGame);
        car1Button.addEventListener('click', () => cars[0].move());
        car2Button.addEventListener('click', () => cars[1].move());
        car3Button.addEventListener('click', () => cars[2].move());

        // Function to make canvas responsive
        function resizeCanvas() {
            const containerWidth = canvas.parentElement.clientWidth;
            canvas.width = containerWidth > 800 ? 800 : containerWidth - 32; // Max 800px, or container width minus padding
            canvas.height = 300; // Fixed height

            // Adjust car positions and finish line if canvas size changes
            initializeCars();
            drawRaceTrack();
            if (!gameRunning) { // If game is not running, ensure cars are at start position
                cars.forEach(car => car.reset());
                drawRaceTrack();
            }
        }

        // Call resizeCanvas on page load and window resize
        window.addEventListener('load', () => {
            resizeCanvas();
            // Disable car buttons initially
            car1Button.disabled = true;
            car2Button.disabled = true;
            car3Button.disabled = true;
        });
        window.addEventListener('resize', resizeCanvas);

    </script>
</body>
</html>
