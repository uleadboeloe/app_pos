<?php
$serverName = "10.234.234.25\SQL2019"; // IP dan DB instance BC
$connectionInfo = array( "Database"=>"dbBC200", "UID"=>"user", "PWD"=>"pass", "TrustServerCertificate"=>true);
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( !$conn ) 
{
     echo "Connection to BC server could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}

?>